# thanks after post plugin

This plugin will add following after every post:
```
Thanks for reading!
v0.9.0
```

where `v0.9.0
